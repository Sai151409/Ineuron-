import logging
logging.basicConfig(filename = "tuple.log", level = logging.INFO, format = "%(asctime)s - %(levelname)s -  %(message)s")
class tp:
    """tp is a tuple class"""
    def __init__(self, tp):
        self.tp = tp
            
    def tp_not_tuple(self):
        """This function check whether the data is tuple class or not 
        if it is list type it will  return 1 or else it will give an error message"""
        if type(self.tp) != tuple:
            raise Exception("It is not tuple data type")
        else:
            return 1
        
    def tp_count(self, c) : 
        """count function gives the number of times a specified element is occured"""
        try:
            logging.info("It is a count function of tuple")
            if self.tp_not_tuple():
                f = self.tp.count(c)
                logging.info(f"The count of value {c} in the tuple is : {f}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
        
    def tp_index(self, d):
        """Index function gives the index place of the specified element in the tuple"""
        try:
            logging.info("It is a index function of tuple")
            if self.tp_not_tuple():
                k = self.tp.index(d)
                logging.info(f"The index value of {d} is : {k}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")