import logging
logging.basicConfig(filename = "set.log", level = logging.INFO, format = "%(asctime)s - %(levelname)s - %(message)s")
class st:
    """st is a set class"""
    def __init__(self, st):
        self.st = st
        
    def st_not_set(self):
        if type(self.st) != set:
            raise Exception("It is not a set data type")
        else:
            return 1
            
    def st_add(self, d):
        try:
            if self.st_not_set():
                logging.info("It adds a element in the set")
                self.st.add(d)
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_clear(self):
        try:
            if self.st_not_set():
                logging.info("It removes the all elements in set")
                self.st.clear()
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_copy(self):
        try:
            if self.st_not_set():
                logging.info("Current set is copied and a assign to a new variable")
                self.st.copy()
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")

            
            
    def st_discard(self, d):
        try:
            if self.st_not_set():
                logging.info("It removes the specified element from the set")
                self.st.discard(d)
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
            
    def st_remove(self, d):
        try:
            if self.st_not_set():
                logging.info("It removes the specified element from the set")
                self.st.remove(d)
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
            
    def st_difference(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It find out the difference between the two sets {self.st} and {d}, but it will not update the current set" )
                logging.info(f"Difference of two sets : {self.st.difference(d)}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_difference_update(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It find out the difference between the two sets {self.st} and {d}, but it will update the current set" )
                self.st.difference_update(d)
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_intersection(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It find out the common elements of two sets {self.st} and {d}, but it will not update the current set" )
                logging.info(f"Intersection of two sets : {self.st.intersection(d)}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_intersection_update(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It find out the common elements of two sets {self.st} and {d}, but it will update the current set" )
                self.st_intersection_update(d)
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_symmetric_difference(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It find out the symmetric difference between the two sets {self.st} and {d}, but it will not update the current set" )
                logging.info(f"Symmetric difference of two sets is : {self.st.symmetric_difference(d)}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_symmetric_difference_update(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It find out the symmetric difference between the two sets {self.st} and {d}, but it will update the current set" )
                self.st.symmetric_difference_update(d)
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_union(self, d):
        try:
            if self.st_not_set():
                logging.info(f"Concatenate two sets but it willn't allow the duplicate values and it will not update the current set" )
                logging.info(f"Union of two sets is : {self.st.union(d)}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_update(self, d):
        try:
            if self.st_not_set():
                logging.info(f"Concatenate two sets but it willn't allow the duplicate values and it updates the current set" )
                self.st.update(d)
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_isdisjoint(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It checks whether there is no common element between the sets " )
                logging.info(f"{self.st} is disjoint of {d} : {self.st.isdisjoint(d)}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_issubset(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It checks whether set {d} is a subset of {self.st}" )
                logging.info(f"{d} is subset of {self.st} : {self.st.issubset(d)}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
            
    def st_issuperset(self, d):
        try:
            if self.st_not_set():
                logging.info(f"It checks whether there is no common element between the sets" )
                logging.info(f"{self.st} is superset of {d} : {self.st.issuperset(d)}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")
            
    def st_pop(self):
        try:
            if self.st_not_set():
                logging.info("It removes the element from the set")
                logging.info(f"The remove element is : {self.st.pop()}")
                logging.info(f"The final set is : {self.st}")
        except Exception as e:
            logging.error("The Error has occured")
            logging.exception(f"The occured error is {e}")